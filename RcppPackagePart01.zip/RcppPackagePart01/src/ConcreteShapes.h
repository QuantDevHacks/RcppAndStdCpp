#ifndef CONCRETE_SHAPES_H
#define CONCRETE_SHAPES_H

#include <cmath>

class Circle
{
public:
  Circle(double radius);
  double area() const;
  
private:
  double radius_;
};

class Square
{
public:
  Square(double side);
  double area() const;

private:
  double side_;
};

#endif