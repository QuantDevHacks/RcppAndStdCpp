#include "ReusableCppSourceCode.h"
#include <vector>
#include <algorithm>
#include <numeric>
#include <cmath>

double add(double x, double y)
{
  return x + y;
}

vector<double> sortVec(vector<double> v)
{
  sort(v.begin(), v.end());
  return v;
}

double stdMean(vector<double> vec) 
{
  return accumulate(vec.cbegin(), vec.cend(), 0.0)/static_cast<double>(vec.size());
}

double integSum(double k, double phi, double t)
{
  // std::ellint_1(.) and std::expint(.), elliptic and 
  // exponential integral functions respectively, are 
  // C++17 library functions that are supported by 
  // the MinGW compiler included with Rtools 4.0.

  return std::ellint_1(k, phi) + std::expint(t);
}