#include <vector>
using std::vector;

double add(double x, double y);

vector<double> sortVec(vector<double> v);

double stdMean(vector<double> vec); 

double integSum(double k, double phi, double t);