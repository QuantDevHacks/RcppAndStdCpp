#include "ReusableCppSourceCode.h"
#include <vector>
#include <cmath>
#include <algorithm>  // std:copy(.)

#include <Rcpp.h>     // For Rcpp::NumericVector

using std::vector;
using std::copy;

using Rcpp::NumericVector;


// Nonmember Function Interfaces:

// [[Rcpp::export]]
int rcppAdd(double x, double y)
{
  return add(x, y);
}

// [[Rcpp::export]]
NumericVector rcppSortVec(NumericVector v)
{
  vector<double> stlVec(v.size());
  copy(v.begin(), v.end(), stlVec.begin());
  
  // Call the reusable sortVec(.) function:
  stlVec = sortVec(stlVec);
  
  // Copy results in vector<int> back into NumericVector.
  // Use same vector v since it has the same length:
  copy(stlVec.begin(), stlVec.end(), v.begin());
  
  // Return as rcpp::NumericVector:
  return v;
}

// [[Rcpp::export]]
double rcppStdMean(NumericVector v) 
{
  vector<double> w(v.size());
  copy(v.begin(), v.end(), w.begin());

  auto mean = stdMean(w);

  return mean;
}

// C++17 example:
// [[Rcpp::export]]
double rcppIntegralSum(double k, double phi, double t)
{
  auto ret = integSum(k, phi, t);
  return ret;
}
